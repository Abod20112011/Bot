class Config:
    API_ID = 
    API_HASH = ""
    TOKEN = ""  
    START_PIC = "" 
    CHAT = ""    
